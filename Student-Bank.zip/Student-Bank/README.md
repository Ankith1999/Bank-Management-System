# Student-Bank
Online Banking Management System

-----------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------

It is a highly secured internet banking web platform which satisfies all the banking needs of a customer's digitally. It covers all the major modules of real banking system. Most of the event of the system is tied up with OTP and SMS notification to the customer's registered mobile number which ensures integrity and security of the system. Highly user-friendly interface is the key factor of the project, which ensures the easy of use for the customer's keeping in mind that every aspect of online 
banking is easily interpreted and understood by even the novice customer's.

Database name is "bank_db"

You just need below to steps to use this we application.

Step 1 - Download or clone the file to your server's public folder (htdocs for XAMPP  or www for WAMP)

Step 2 - Create a new database in your PhpMyAdmin (Database name should be "bank_db")

Step 3 - Import the database to your PhpMyAdmin in the newly created database (Database(SQL) path homefolder/database/bank_db.sql)

Step 4 - Use the following credentials or register for new account opening and then internet banking.

Login Credentials (Demo)

Customer Login
ID : 10111
Password : junaid@123

Staff Login
ID : 210001
Password : junaid@123

Hurray!! the banking web application is setup and is ready to be used.

=================================================================

If any error, please let me know

My Contact :
+91 7278523122 (Call + WhatsApp)
mail@junaidashraf.com
junaid@jscreeper.com
My Website : https://www.junaidashraf.com (Personal)
			 https://www.jscreeper.com (Professional)

=================================================================

For more projects like this or real big projects please connect to me or my team to get a best budget.

Here is my Web and App development business website link and email. We also provide Web Hosting. Please get in touch.

https://www.jscreeper.com
support@jscreeper.com
+91 7278523122 (Call + WhatsApp)

=================================================================

I am also avaiable at Freelancer, hire me at

https://www.freelancer.in/u/JunaidAshraf10

=================================================================

Have a great day.