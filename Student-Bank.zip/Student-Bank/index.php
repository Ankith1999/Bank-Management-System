<html>
<title>Student Bank</title>
<head>
   <link rel="stylesheet" type="text/css" href="css/index.css">
   <link rel="shortcut icon" href="chase _title.jpg">
    </head>
 
<body>
<?php include'header.php'?>
<div class="index_container">
    <div class="slider">
    <div class="slideimg">
    <img src="img/slide%20(1).jpg">
        <img src="img/slide%20(2).jpg">
        <img src="img/slide%20(3).jpg">
        <img src="img/slide%20(4).jpg">
        <img src="img/slide%20(5).jpg">
        </div>
    </div><br>
    <div class="newsroom">
        
        <marquee class="marquee_news" scrolldelay="20"><p class="newsfeed"><span>Your bank may charge you for closing a bank account. 
        Bank also charges you when you close your account within a particular time period.</span><span>SBI cuts deposit rates; PPF to fetch lower interest rate. </span><span>No, it is not mandatory to link your bank account with Aadhar card</span></p></marquee>
    </div><br><br>
   

    
<div class="news_events">
    <h4>News | Updates | Events</h4><br>
        <ul>
            <p>PNB lost four times more money than SBI did to 'jewel thieves‘
 </p><br>
<p>PNB's letter explains why it went public about the fraud, wants workable plan from Nirav Modi

</p><br>

<p>Indian Bank Q3 profit falls 19%, but NII grows 30%, asset quality improves</p>
            <br>
        </ul>
    </div>
    

    <div class="online_services">
        <h4>Online Services</h4>
        <ul>
            <a href="customer_reg_form.php"><li>Open Account</li></a>
            <a href="debit_card_form.php"><li>Apply Debit Card</li></a><br>
            <a href="" id="ebanking" ><li><div class="ebanking">Internet Banking
                <div class = "ebanking_options">
                <ul>
                    <a href="customer_login.php"><li>Login </li></a>
                    <a href="ebanking_reg_form.php"><li>Register</li></a>
                </ul>
            </div>
        </div>
    </li></a>
            <a href="fund_transfer.php"><li>Fund Transfer</li></a><br>
            <a href="bank_branch.php"><li>Branch Locator</li></a>
            <a href="https://bankifsccode.com/"><li>Find IFSC Code</li></a>
        </ul>
   
</div>

        <div id="aboutus" class="about"><span>About Us</span><br><br>
        <p>Student Bank of India (SBI) is one of the 14 major banks which were nationalized on July 19, 1969. Its predecessor the United Bank of India Ltd., was formed in 1950 with the amalgamation of four banks viz. Comilla Banking Corporation Ltd. (1914), Bengal Central Bank Ltd. (1918), Comilla Union Bank Ltd. (1922) and Hooghly Bank Ltd. (1932) (which were established in the years indicated in brackets after the names). The origin of the Bank thus goes as far back as to 1914. As against 174 branches, Rs. 147 crores of deposits and Rs. 112 crores of advances at the time of nationalisation in July, 1969, today the Bank is 100% CBS enabled with 1999 branches and offices and is having a Total business of more than Rs 2 lac crore. Presently the Bank is having a Three-tier organisational set-up consisting of the Head Office, 35 Regional Offices and the Branches.</p><p>After nationalisation, the Bank expanded its branch network in a big way and actively participated in the developmental activities, particularly in the rural and semi-urban areas in conformity with the objectives of nationalisation. In recognition of the role played by the Bank, it was designated as Lead Bank in several districts and at present it is the Lead Bank in 30 districts in the States of West Bengal, Assam, Manipur and Tripura. The Bank is also the Convener of the State Level Bankers' Committees (SLBC) for the States of West Bengal and Tripura.
</p></div>
    
    <div class="disclaimer">
    <span>Disclaimer !!</spasn><br><br>
        <p>Our bank does not ask for the details of your account/PIN/password. Therefore any one pretending to be asking you for information from the bank/technical team may be fraudulent entities, so please beware.</p>
        <p>You should know how to operate net transactions and if you are not familiar you may refrain from doing so. You may seek bank's guidance in this regard. Bank is not responsible for online transactions going wrong.</p>
        <p>We shall also not be responsible for wrong transactions and wanton disclosure of details by you. Viewing option and transaction option on the net are different. You may exercise your option diligently.</p>
    </div>


    </div>
    
<?php include 'footer.php';?>
</body>

</html>