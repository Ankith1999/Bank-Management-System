<link rel="stylesheet" type="text/css" href="css/footer.css">
<footer>
<div class="container">
<div class="follow_us">
    <label>Follow Us</label>
    <ul>
        <li><a href="https://www.facebook.com/">Facebook</a></li>
        <li><a href="https://twitter.com/">Twitter</a></li>
        <li><a href="https://www.instagram.com/?hl=en">Instagram</a></li>
    
    </ul>
    </div>
    <div class="contact" id="contactus">
        <label>Contact Us</label>
        <ul>
            <p>Bmsit</p><p>Avallahalli, Bangalore 560013</p>
            <p>Tel : 033 2482 0676</p>
            <p> Email: contact@bmsit.in</p>
            
        </ul>
    </div>
        <div class="links">
            <label>Important Links</label>
            <ul>    
            <li><a href="index.php#aboutus" target="_blank">About Us</a></li>
            <li><a href="https://bankifsccode.com/">Bank IFSC Code</a></li>
            <!-- <li><a href="">Loan</a></li> -->
            <li><a href="gst.php">Goods & Services Tax</a></li>
            <!-- <li><a href="">Calculator</a></li>  -->
            </ul><br>
    </div>
     <!-- <div class="About_GST">
            <label>About GST</label>
            <ul>    
            <li><a href="gst.php">GST Council Structure</a></li>
            <li><a href="gst.php">GST History</a></li>
            </ul><br>
    </div> -->
    
    </div>
    <div class="copyright">
        <span>Copyright &copy; 2020-21 Student Bank. All rights reserved.</span>
    </div>
    
    <div class="bestview">
    <span>Site best viewed at 1024 x 768 resolution in Internet Explorer 10+, Google Chrome 49+, Firefox 45+ and Safari 6+</span>
    
    </div>

</footer>